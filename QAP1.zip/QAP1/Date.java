package QAP1;

public class Date {

    private int day;
    private int month;
    private int year;

    //constructor
    public Date (int day, int month, int year){
        this.day = day;
        this.month = month;
        this.year = year;
    }

    //get
    public int getDay(){
        return day;
    }
    public int getMonth(){
        return month;
    }
    public int getYear(){
        return year;
    }

    //setting date perameters (1-31)(1-12)(1900-9999)
    public void setDay(int day){
        if (day >=1 && day <=31){
            this.day =day;
        }else {
            System.out.println("Invalid day. Day must be between 1 and 31.");
        }
    }
    public void setMonth(int month){
        if (month >=1 && month <=12){
            this.month =month;
        }else{
            System.out.println("Invalid month. Month must be between 1 and 12.");
        }
    }
    public void setYear(int year){
        if (year >1900 && year <=9999){
            this.year = year;
        } else {
            System.out.println("Invalid year. Year must be between 1900 and 9999.");
        }
    }

    //setting uop the date
    public void setDate(int day, int month, int year){
        this.day = day;
        this.month = month;
        this.year =year;
    }

    //creating a date string as dd/mm/yy
    @Override
public String toString() {
    return String.format("%02d/%02d/%04d", day, month, year);
}
}

package QAP1;

public class TestDate {
    
    public static void main(String[] args) {
        Date d1 = new Date(05,14,2024);
    

    System.out.println("Today's date is: " + d1 + ".");
    }
 }
